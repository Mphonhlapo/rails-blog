class Pioneer < ApplicationRecord
end
